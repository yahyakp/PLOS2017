function [Stim raw_stim] = generate_stim(X , pattern , rate , varargin)

% GENERATE_STIM either receives the size of the spike data or the spike
% data itself. It then generates a stimulus data with the same size. The
% PATTERN denotes the number of neurons that receive the poisson input with
% a certain rate.
% (c) 2015 Yahya Karimipanah. If you use this code, please cite:
% Y. Karimipanah, Z. Ma & Ralf Wessel. "Criticality predicts maximum irregularity 
% in recurrent networks of excitatory node", PLOS ONE, 2017.

% INPUTS:
%     data or size of data          - size of the spike train (NxT raster).
%     pattern                       - a binary vector indicating the neurons
% who receive external drive.
% rate                              - the rate of the incoming non-filtered inputs.

% OPTIONAL INPUT:
%     width                         - width of Gaussian filter. The default value is 50.

% OUTPUTs:  
%     Stim                          - an NxT Stimuli matrix, containing the
% external drive to all neurons. The entries are the spike probabilities
% due to external input.
%     raw_stim                      - The non-filtered stimulus matrix,
% containing an NxT binary matrix. Each row of Stim is indeed the same row
% of raw_stim convolved with a Gaussian filter.

% Examples:
%     [Stim , ~ , raw_stim] = generate_stim([N , T] , pattern , rate)
%     Stim = generate_stim(data , pattern , rate)           % default width = 50
%     Stim = generate_stim(data , pattern , rate , 20)      % width = 20

N = length(pattern);
flag = 0;
width_flag = 0;
switch nargin    
            
    case 3
        if  isnumeric(vertcat(X(:),pattern(:),rate))==1 ...
                && numel(X)==length(X) ...
                & isempty(find( spfun(@(x) x>=0 , vertcat(X(:),pattern(:)) )~=0 &...
                            spfun(@(x) x>=0 , vertcat(X(:),pattern(:)))~=1)) && rate >=0 ...
                & length(pattern)==numel(pattern)  ...
                & numel(pattern)==N & length(X)==2
            X = reshape(X,1,numel(X));
            N = X(1);
            T = X(2);
            Stim = sparse(N,T);
            if ~isempty(find(pattern~=0 & pattern~=1))
                pattern = sign(pattern);
                warning('PATTERN should be a binary vector! The input is binarized');
            end
            pattern = reshape(sparse(pattern) , numel(pattern) , 1);
            
        elseif prod(cellfun(@isnumeric , {X,pattern,rate}))==1 ...
                && numel(X)~=length(X) ...                
                && isempty(find( spfun(@(x) x>=0 , horzcat(X,pattern) )~=0 & ...
                spfun(@(x) x>=0 , horzcat(X,pattern))~=1)) && rate >=0 ...
                && length(pattern)==numel(pattern) && numel(pattern)==N
            [N T] = size(X);
            Stim = sparse(N,T);
                            
            if ~isempty(find(pattern~=0 & pattern~=1))
                pattern = sign(pattern);
                warning('PATTERN should be a binary vector! The input is binarized');
            end
                
        else
            error(horzcat('PATTERN should be a binary vector of maximum length ',num2str(N)));
        end  
    case 4
        if  isnumeric(vertcat(X(:),pattern(:),rate))==1 ...
                && numel(X)==length(X) ...
                & isempty(find( spfun(@(x) x>=0 , vertcat(X(:),pattern(:)) )~=0 &...
                            spfun(@(x) x>=0 , vertcat(X(:),pattern(:)))~=1)) && rate >=0 ...
                & length(pattern)==numel(pattern)  ...
                & numel(pattern)==N & length(X)==2
            X = reshape(X,1,numel(X));
            N = X(1);
            T = X(2);
            Stim = sparse(N,T);
            if ~isempty(find(pattern~=0 & pattern~=1))
                pattern = sign(pattern);
                warning('PATTERN should be a binary vector! The input is binarized');
            end
            pattern = reshape(sparse(pattern) , numel(pattern) , 1);
            
        elseif prod(cellfun(@isnumeric , {X,pattern,rate}))==1 ...
                && numel(X)~=length(X) ...                
                && isempty(find( spfun(@(x) x>=0 , horzcat(X,pattern) )~=0 & ...
                spfun(@(x) x>=0 , horzcat(X,pattern))~=1)) && rate >=0 ...
                && length(pattern)==numel(pattern) && numel(pattern)==N
            [N T] = size(X);
            Stim = sparse(N,T);
                            
            if ~isempty(find(pattern~=0 & pattern~=1))
                pattern = sign(pattern);
                warning('PATTERN should be a binary vector! The input is binarized');
            end
                
        else
            error(horzcat('PATTERN should be a binary vector of maximum length ',num2str(N)));
        end
        
        if isnumeric(varargin{end}) && numel(varargin{end})==length(varargin{end})
            width = varargin{end};
            width_flag = 1 ; 
        else
            error('The fourth argument should be the width of the Gaussian filter!')
        end
        
    otherwise
        error('Wrong nmber of input arguments!');
end

idx = find(pattern==1);
if flag==1        
    
    x0 = poissrnd(rate/cc , 1 , T);
    X0 = repmat(x0 , length(idx) , 1);
    Stim(idx,:) = X0 .* H(cc-rand(size(X0))) ;
else
    Stim(idx,:) = poissrnd(rate , length(idx) , T);
end
raw_stim = Stim;

if ~width_flag
    width = 50; 
end
    
for i = 1:length(idx)
    Stim(idx(i),:) = convolve(full(Stim(idx(i),:)) , width) / 1;
end

function f = H(x)
    f = x > 0;
end


end




