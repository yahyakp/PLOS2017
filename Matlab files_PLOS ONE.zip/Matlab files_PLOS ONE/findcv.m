function [ CV , ISI] = findcv( data )
% Obtains the CV and ISI of all neurons in the data
%   data should be an NxT matrix, containing the spike-trains for N
%   neurons.
% INPUTs: a spike raster (binary matrix of size NxT)
%OUTPUTs: 
% CV: the coefficent of variation (CV) of all individual neurons.
% ISI: The inter-spike interval for all neurons.

N = size(data,1);

ISI = cell(N,1) ;
CV = zeros(N,1);
for i = 1:N
    ISI{i} = diff(find(data(i,:)>0));
    CV(i) = std(ISI{i})/mean(ISI{i});
end

CV(isnan(CV)==1)=0;

end
