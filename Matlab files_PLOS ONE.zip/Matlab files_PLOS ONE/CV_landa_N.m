% This script is used to show how the relation between Cv and max.
% eigenvalue (mean synaptic efficacy) varies by the size of the network.

% (c) 2015 Yahya Karimipanah. If you use this code, please cite:
% Y. Karimipanah, Z. Ma & Ralf Wessel. "Criticality predicts maximum irregularity 
% in recurrent networks of excitatory node", PLOS ONE, 2017.

clc;
close all;  clear
set(groot, 'defaultaxesfontsize', 16)
set(groot, 'defaultaxeslinewidth', 1.5)
set(groot,'defaultlinelinewidth', 1.5)


name = 'CV_landa_N';
cnc         = 3;            % network connectivity

tmax        = 500;

Landas = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;
netsize = [5e3 1e4 15e3 2e4 ];                  % network sizes
CV = cell(length(netsize),1);

% -------------------------------------------------------------------------
% if you want to test this without parallel computing toolbox, just comment
% this section and change the parfor to for
g = gcp('nocreate') ;
if isempty(g)
        c = parcluster;
        c.NumWorkers = 30 ;          % number of parallel workers
        saveProfile(c) ;
        parpool(c , c.NumWorkers) ;
end
% -------------------------------------------------------------------------

dataset = cell(length(netsize) , 1);

for n = 1:length(netsize)
    
    N   = netsize(n)
    etta = 1/N/2;
    name = ['CV_landa_', num2str(N)];
    CVstat = [];
    idx = datasample(1:N , 500 , 'replace', false) ;
    
    for j = 1:length(Landas)
        N
        landa = Landas(j)
        W           = landa * generate_W(N , 1) ;       
    % ------------------------------------------------------------------------- 
    % the values for max_iter are chosen aritrarily to reduce the run time,
    % especially for the super critical regime (landa > 1)
        if landa <= 0.97                
            max_iter = 60;
        elseif landa <= 1.0
            max_iter = 50;
        elseif landa <=1.03
            max_iter = 50;
        elseif landa <= 1.05
            max_iter = 30;
        else
            max_iter = 10;
        end
       
        Niter = 30;    % the number of generated spike trains. They are generated in parallel and are finally concatenated.
    % -------------------------------------------------------------------------

        data = cell(1,Niter);

        parfor iter = 1:Niter
            iter;
            data{iter} = generate_spikes(W , 0 ,  tmax , max_iter ,[] , 'stim',ones(N,1)*1/N/5);
        end

        Data                = cell2mat(data);
        cv                  = findcv(Data(1:1000,:));       % CV's are calculated for 1000 neurons, just to reduce the run time
        coupling            = findcoupling(Data(idx,:));    % population coupling is calculated for 500 randomly chosen neurons
        CVstat          = [CVstat ; mean(cv) mean(coupling) ] ;         
        
    end
       
    dataset{n} = CVstat;

    ll              = min(Landas):0.001:max(Landas);
    CCmean          = spline(Landas , CVstat(:,2) , ll);  
    CVmean          = spline(Landas , CVstat(:,1) , ll);
    
    CV{n}.landas    = ll;
    CV{n}.CVmean    = CVmean;
    CV{n}.max       = max(findpeaks(CCmean));
    CV{n}.coupling  = (spline(Landas , CVstat(:,2) , ll));
end

    delete(gcp)

col = { [0 0 0.8] , [0.8 0 0] , [0 0.8 0] , 'k' } ;

trend = [];
for n = 1:length(netsize)
    
    ll              = CV{n}.landas;
    CVmean          = CV{n}.CVmean;
    CCmean          = CV{n}.coupling;
    
    trend   = [trend ; netsize(n) max(CVmean) ll(CVmean==max(CVmean)) ];
    
    figure(1)
    hold on
    plot(ll , CVmean ,'color',col(n,:), 'linewidth', 2 )
    
    figure(2)
    hold on
    plot(ll , CCmean ,'color',col(n,:), 'linewidth',2.)   
       
end

figure(1)
legend( horzcat('N = ' , num2str(netsize(1)) ) , horzcat('N = ' , num2str(netsize(2)) ) , ...
    horzcat('N = ' , num2str(netsize(3)) ) , horzcat('N = ' , num2str(netsize(4)) ) )
xlabel('\lambda' )
ylabel('CV')
legend boxoff
    
figure(2)
legend( horzcat('N = ' , num2str(netsize(1)) ) , horzcat('N = ' , num2str(netsize(2)) ) , ...
    horzcat('N = ' , num2str(netsize(3)) ) , horzcat('N = ' , num2str(netsize(4)) ) )
xlabel('\lambda' )
ylabel('Coupling')
legend boxoff

