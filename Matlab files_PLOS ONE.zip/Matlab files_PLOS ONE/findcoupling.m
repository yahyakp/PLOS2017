function couplings = findcoupling(data , varargin)

% This function computes the population coupling constant.

% INPUTS    - spike train (raster) data for N neurons, which is in
% the form of an NxT binary matrix.
% OUTPUTS   - Population coupling of all N neurons.

% OPTIONAL INPUTS
%     'xcorr'              - calculates the correlations without mean subtraction.
%     'cov'                - calculates covariance
%     'economy' or 'econ'  - the option for using low memory, though there will
%     be a compromise on speed.
%     'type',...           - calculates Spearman or Kendal correlation instead
%     of Peason correlation.

% (c) 2015 Yahya Karimipanah. If you use this code, please cite:
% Y. Karimipanah, Z. Ma & Ralf Wessel. "Criticality predicts maximum irregularity 
% in recurrent networks of excitatory node", PLOS ONE, 2017.

% Examples:
%     couplings = findcoupling(data);           the fast way
%     couplings = findcoupling(data , 'cov');
%     couplings = findcoupling(data , 'xcorr');     correlation without mean-subtracting
% 
%     couplings = findcoupling(data , 'type' , 'spearman');
%     couplings = findcoupling(data , 'economy');    is much slower but takes less memory. 
%     couplings = findcoupling(data , 'econ' , 'type' , 'Kendall');
%     Only use 'econ' when you run out of Memory


if isnumeric(data) || islogical(data)
            [N T] = size(data);
end

if N > T
    data = data';
end

netdata     = sum(data);

switch nargin
    case 1
        Data       = mat2cell(data , ones(1,N) , T);
        couplings  = cellfun(@(x) corr(full(x'),full(netdata'-x')) ,Data );
        
    case 2
        if strcmp(varargin{1},'econ') || strcmp(varargin{1},'economy')
            couplings = zeros(N,1);
            for i = 1:N
                data2           = bsxfun(@minus , netdata , data);
                couplings(i)    = corr(data2(i,:)' , data(i,:)');
                display(horzcat(num2str(i) , ' / ',num2str(N)) );
            end
        elseif strcmp(varargin{1},'xcorr')
            Data       = mat2cell(data , ones(1,N) , T); 
            couplings  = cellfun(@(x) xcorr(full(x),full(netdata-x),0,'coeff') ,Data );
            
        elseif strcmp(varargin{1},'cov')
            Data       = mat2cell(data , ones(1,N) , T);
            couplings  = cellfun(@(y) y(1,2) , cellfun(@(x) cov(full(x),full(netdata-x)) ,Data ...
                                                                                ,'UniformOutput',false)); 
        else
            error('Wrong Input Argument: it should be either "economy" or "econ"');
        end
        
    case 3
        if strcmp(varargin{1},'type') && (strcmp(varargin{2},'Kendall') || strcmp(varargin{2},'pearson') || strcmp(varargin{2},'spearman') )
            type = varargin{2};
            Data       = mat2cell(data , ones(1,N) , T);
        couplings  = cellfun(@(x) corr( transpose(full(x)),transpose(full(netdata-x)) , 'type',type) ,Data  ) ;
        
        elseif ((strcmp(varargin{1},'econ') || strcmp(varargin{1},'econ')) && strcmp(varargin{2},'cov')) 
            couplings = zeros(N,1);
            for i = 1:N
                data2           = bsxfun(@minus , netdata , data) ;
                C               = cov(data2(i,:) , data(i,:) ) ;
                couplings(i)    = C(1,2) ;
                display(horzcat(num2str(i) , ' / ',num2str(N)) );
            end
        elseif ((strcmp(varargin{1},'econ') || strcmp(varargin{1},'econ')) && strcmp(varargin{2},'xcorr')) 
            couplings = zeros(N,1);
            for i = 1:N
                data2           = bsxfun(@minus , netdata , data) ;
                couplings(i)    = xcorr(data2(i,:) , data(i,:) ,0 , 'coeff') ;
                display(horzcat(num2str(i) , ' / ',num2str(N)) );
            end 
        else
            error('The format of the input argument or the type of correlation is wrong!');
        end
                               
    case 4
        
        if (strcmp(varargin{1},'econ') || strcmp(varargin{2},'economy')) && strcmp(varargin{2},'type') ...
                                       || (strcmp(varargin{3},'Kendall') || strcmp(varargin{3},'pearson') || strcmp(varargin{3},'spearman') )
            type = varargin{3};
            couplings = zeros(N,1);
            for i = 1:N
                data2           = bsxfun(@minus , netdata , data);
                couplings       = corr(transpose(full(data2(i,:))) , transpose(full(data(i,:)))  , 'type' , type);
                display(horzcat(num2str(i) , ' / ',num2str(N)) );
            end
        else
            error('Wrong Input Argument: Please see the examples!');
        end
                                               
    otherwise
        error('Wrong Input Argument!');
end


