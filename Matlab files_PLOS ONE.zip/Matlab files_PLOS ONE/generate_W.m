function W = generate_W(N , cnctvt , varargin)
% Genrates a transfer matrix for an Erdos-Renyi Network of size N and cnctvt % connectivity
% This function is used as an adjunct to "generate_spikes.m", which is used to 
% simulate spike trains of a network of binary probabilistic neurons. 
% 
% (c) 2015 Yahya Karimipanah. If you use this code, please cite:
% Y. Karimipanah, Z. Ma & Ralf Wessel. "Criticality predicts maximum irregularity 
% in recurrent networks of excitatory node", PLOS ONE, 2017.
% 
% Inputs:
% N         - size of the network
% cnctvt    - network connectivity
% E/I ratio - The ration between excitation and inhibition
% 
% Example: 
% W = generate_W(1e4 , 5 ); generates a transfer matrix for a
% network of 10000 neurons with 5% connectivity.
% 
% W = generate_W(1e3 , 5 );
% W = generate_W(1e3 , 50 , 'k')
% W = generate_W(1e3 , 5 , '%')
% W = generate_W(1e3 , 5 , 20)  % I/E ratio = 20%
% W = generate_W(1e3 , 50 , 'k', 20 , 'ii' , 0)

tic
flag = 0;

    switch nargin
        case {4 , 6}
            ch_idx  = find(cellfun(@ischar,varargin)==1);
            num_idx = find(cellfun(@isnumeric,varargin)==1);
            
            if isempty(ch_idx) 
                error('Wrong input arguments!!')
            elseif length(ch_idx)==1 && strcmp('k',varargin{ch_idx})
                k = varargin{ch_idx};
            elseif length(ch_idx)==1 && strcmp('ii',varargin{ch_idx}) 
                if varargin{ch_idx+1}==0
                    flag = 1
                elseif varargin{ch_idx+1}==1
                    flag = 0;
                else
                    error('Wrong input arguments!, ii value should be either 0 or 1')
                end
                
            elseif length(ch_idx)==2
                ii_idx      = find(cellfun(@(x) strcmp(x,'ii')   , varargin)==1)
                if ~isempty(ii_idx)
                    if varargin{ii_idx+1}==0
                        flag = 1
                    elseif varargin{ii_idx+1}==1
                        flag = 0;
                    else
                        error('Wrong input arguments!, ii value should be either 0 or 1')
                    end
                end
                k_idx       = find(cellfun(@(x) strcmp(x,'k')    , varargin)==1)
                prcnt_idx   = find(cellfun(@(x) strcmp(x,'%')    , varargin)==1)
                if xor(prcnt_idx , k_idx)
                    error(['Wrong input: the connectivity should be either as ...', ... 
                    'the number of connections or as the connectivity percentage'])
                elseif isempty(k_idx)
                    k = round(cnctvt * N/100);
                else
                    k = varargin{k_idx-1};
                end
                            
                                                                  
            else
                error('Wrong input arguments! Please refer to the function`s comments')
            end
            
         
        case 3
            if ischar(varargin{1})
                if strcmp(varargin{1},'k')
                    k = varargin{2};
                elseif strcmp(varargin{1},'%')
                    k = round(cnctvt * N/100);
                else
                    error('Wrong input argument!!')
                end
            elseif isnumeric(varargin{1}) 
                if varargin{1} <=1 && varargin{1} > 0
                    Ni = round(varargin{1} * N);
                    Ne = N - Ni;
                    k = round(cnctvt * N/100);
                    if varargin{1} >= 0.5
                        warning('The E/I ratio is less than %50!!')
                    end
                end
            else
                error('Wrong input argument!')
            end
            
                                                    
        case 2
            k = round(cnctvt * N/100);
        otherwise
            error('Wrong number of arguments!!')
    end  
    
    
    sigma=1;                     % average local branching ratio
%     k=50;                        % average connectivity
    pmax=2*sigma/k;
 
    if N < 3e3
        v=sparse(1,(N-1)*N); % this vector will be used to form random connections between elements
        v(1,randperm((N-1)*N,k*N))=1;
        v = pmax * v .* (rand(size(v))); % each connection has random strength from 0 to pmax
        W=sparse(zeros(N));                          % create weight matrix
        W((ones(N)-eye(N))==1)=v;    
    elseif N < 5e3            
        v = sparse(1,N^2);
        v(1,randperm(N^2,floor(k*N)))=1;       
        v = pmax * v .* (rand(size(v))); % each connection has random strength from 0 to pmax
        W = reshape(v,N,N);
        W(eye(N)==1) = 0;
    else
        v = pmax * (rand(1,k*N));
        I = datasample(1:N , k*N );
        J = datasample(1:N , k*N );
        W = sparse(I,J, v , N , N  );
        W(diag(diag(W))~=0) = 0;
    end
    
    toc
    
    if flag == 1
        W(Ne+1:end,Ne+1:end) = 0;
    end
    
    
end

    