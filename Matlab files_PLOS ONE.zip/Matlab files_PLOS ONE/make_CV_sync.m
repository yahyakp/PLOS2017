
function make_CV_sync( netsize , epsilon , Niter ) 

% This function generates spike trains for a network of neurons receiving
% synchronous input.
% (c) 2015 Yahya Karimipanah. If you use this code, please cite:
% Y. Karimipanah, Z. Ma & Ralf Wessel. "Criticality predicts maximum irregularity 
% in recurrent networks of excitatory node", PLOS ONE, 2017.

% INPUTs:
%     netsize             - network size 
%     epsilon             - refer to the paper.
%     Niter               - number of iterations in the parallel loop (parfor)

% OPTIONAL INPUTs:
%     Nworker                 - number of workers for parallel computing (default is 20)
%     Landas                  - a vector of eigenvalues at which the CV's are
% computed. The default is given by: Landas      = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;

% Examples:
%     cv = make_CV_sync( netsize , epsilon , Niter ) 
%     cv = make_CV_sync( netsize , epsilon , Niter , Nworker ) 
%     cv = make_CV_sync( netsize , epsilon , Niter , Nworker , Landas ) 


if nargin == 5
    Nworker     = varargin{1} ;     
    Landas      = varargin{2} ;
elseif nargin ==4
    Nworker     = varargin{1} ; 
    Landas      = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;
else
    Nworker     = 20 ;
    Landas      = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;
end

tmax        = 500;

g = gcp('nocreate') ;
% -------------------------------------------------------------------------    
if isempty(g)
        c = parcluster;
        c.NumWorkers = Nworker ;
        saveProfile(c) ;
        parpool(c , c.NumWorkers) ;
end
% -------------------------------------------------------------------------
% for m = 1:length(widths)
%     for n = 1:length(Epsilons)
                
        Eta0         = 0.2 ;
        N   = netsize ;
        CVstat = [];

        for j = 1:length(Landas)
            N
            landa = Landas(j)
            W           = landa * generate_W(N , 1) ;       
        % -------------------------------------------------------------------------    
            if landa < 0.9
                max_iter = 150;
            elseif landa <= 0.94
                max_iter = 100;
            elseif landa <= 0.97                
                max_iter = 70;
            elseif landa <= 1.0
                max_iter = 50;
            elseif landa <= 1.05
                max_iter = 40;
            else
                max_iter = 35;
            end
         % -------------------------------------------------------------------------    

            idx = datasample(1:N , 500 , 'replace' , false);
            data = cell(1,Niter);

            parfor iter = 1:Niter

                    [Stim,~,raw_stim] = generate_stim([1 tmax*max_iter] , 1 , 10/N , 100);
                    Stim = repmat(Stim , N/10 , 1);
                    Stim = bsxfun(@times , Stim , Eta0 + epsilon*randn(size(Stim,1) , 1) ) ;
                    Stim = vertcat( Stim , sparse(9*N/10 , tmax*max_iter) ) ; 

                    data{iter} = generate_response(W, 0 , tmax , max_iter , Stim );
            end

            Data                = cell2mat(data);
            cv                  = findcv(Data);
            coupling            = findcoupling(Data(idx,:));

            CVstat          = [CVstat ; mean(cv)   1.96*std(cv)/sqrt(length(cv))   mean(coupling)   1.96*std(coupling)/sqrt(500) ] ; 

        end

        ll              = min(Landas):0.001:max(Landas);
        CCmean          = spline(Landas , CVstat(:,3) , ll);
        CVmean          = spline(Landas , CVstat(:,1) , ll);      
%     end
% end

    delete(gcp)
% ----------------------------------------------------------------
    
        
figure(1)
hold on
plot(ll , CVmean ,'k', 'linewidth', 2 )
plot(Landas , CVstat(:,1) , 'o' , 'markerfacecolor' , 'k' , 'markeredgecolor', 'none' , 'markersize' , 10 )
legend( horzcat('N = ' , num2str(netsize(1)) ) , horzcat('N = ' , num2str(netsize(2)) ) , ...
    horzcat('N = ' , num2str(netsize(3)) ) , horzcat('N = ' , num2str(netsize(4)) ) )
xlabel('\lambda' )
ylabel('CV')
legend boxoff
title('Synchronous Input')

figure(2)
hold on
plot(ll , CCmean ,'k', 'linewidth',2.)
plot(Landas , CVstat(:,3) , 'o' , 'markerfacecolor' , 'k' , 'markeredgecolor', 'none' , 'markersize' , 10 )
legend( horzcat('N = ' , num2str(netsize(1)) ) , horzcat('N = ' , num2str(netsize(2)) ) , ...
    horzcat('N = ' , num2str(netsize(3)) ) , horzcat('N = ' , num2str(netsize(4)) ) )
xlabel('\lambda' )
ylabel('Coupling')
legend boxoff
title('Synchronous Input')
       
