
function CV = make_CV_k( netsize , K , Niter , varargin) 
% This function generates figures to demonstrate the relation between mean
% CV of inter-spike intervals of neurons and the networks mean synaptic
% efficacy (in terms of max. eigenvalue).
% (c) 2015 Yahya Karimipanah. If you use this code, please cite:
% Y. Karimipanah, Z. Ma & Ralf Wessel. "Criticality predicts maximum irregularity 
% in recurrent networks of excitatory node", PLOS ONE, 2017.

% INPUTs:
%     netsize             - network size 
%     K                   - network connectivity
%     Niter               - number of iterations in the parallel loop (parfor)

% OPTIONAL INPUTs:
%     Nworker                 - number of workers for parallel computing (default is 20)
%     Landas                  - a vector of maximum eigenvalues at which the CV's are
% computed. The default is given by: Landas      = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;

% Examples:
%     cv = make_CV_k(Nsize , K  , Niter , Nworker , Landas)
%     cv = make_CV_k(Nsize , K  , Niter , Nworker )
%     cv = make_CV_k(Nsize , K  , Niter )

if nargin == 5
    Nworker     = varargin{1} ;     
    Landas      = varargin{2} ;
elseif nargin ==4
    Nworker     = varargin{1} ; 
    Landas      = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;
else
    Nworker     = 20 ;
    Landas      = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;
end

tmax        = 500;

N = netsize ;  %= 5e3 ;     

CV = cell(length(netsize),1);

g = gcp('nocreate') ;
% -------------------------------------------------------------------------    
if isempty(g)
        c = parcluster;
        c.NumWorkers = Nworker ;
        saveProfile(c) ;
        parpool(c , c.NumWorkers) ;
end
% -------------------------------------------------------------------------

dataset = cell(length(K) , 1);

for n = 1:length(K)
    
    cnc = K(n) ;
    CVstat = [];
    
    for j = 1:length(Landas)
        N
        landa = Landas(j)
        W           = landa * generate_W(N , cnc) ;       
    % -------------------------------------------------------------------------    
        if landa <= 0.97                
            max_iter = 150;
        elseif landa <= 1.0
            max_iter = 100;
        elseif landa <=1.03
            max_iter = 100;
        elseif landa <= 1.05
            max_iter = 50;
        else
            max_iter = 20;
        end

        data = cell(1,Niter);

        parfor iter = 1:Niter
            data{iter} = generate_spikes(W , 0 ,  tmax , max_iter , [] , 'stim',ones(N,1)*1/N/5);

        end

        Data                = cell2mat(data);
        cv                  = findcv(Data(1:1000,:));       % finding the CV of 1000 neurons, just to reduce the time        
        coupling            = findcoupling(Data(1:200,:));  % finding the CV of 200 neurons, just to reduce the time

        CVstat          = [CVstat ; mean(cv) mean(coupling) ] ; 
        
    end
       
    dataset{n} = CVstat;

    ll              = min(Landas):0.001:max(Landas);
    CCmean          = spline(Landas , CVstat(:,2) , ll);
     
    CVmean          = spline(Landas , CVstat(:,1) , ll);
    
    
    CV{n}.CVstat    = CVstat ;
    CV{n}.landas    = ll;
    CV{n}.CVmean    = CVmean;
    CV{n}.subsample = CVmean_sample;
    CV{n}.max       = max(findpeaks(CCmean));
    CV{n}.coupling  = (spline(Landas , CVstat(:,2) , ll));
end

    delete(gcp)

%% ################################### Plotting CV ###################################
figure;     hold on
colors = get(gca,'ColorOrder');
colors = colors([1 5 7],:) ;
Markers  = { 's', 'o' , 'd' , '' , 'd'}

for ii = 1:3
    
    Landas = horzcat( 0.94:0.01:1.0 , 1.01:0.01:1.09 ) ;
    cv = CV{ii}.CVstat(:,1) ;
    plot(Landas , cv , Markers{ii} , 'o' , 'markerfacecolor' , colors(ii,:) , 'markeredgecolor', ...
        'none' , 'markersize' , 7 ,'color',colors(ii,:),'linestyle','-', 'linewidth',2.2)
    ylabel('CV') ;
end
% h = gcf;
% h.Children.YAxis(1).Color = 'k' ;   h.Children.YAxis(2).Color = 'k' ;
    legend('1%','10%','20%') ; pause(0.1) ;  legend boxoff
xlabel('\lambda' , 'fontsize',22 , 'fontweight','b')

ax = gca;
ax.XTick(1:2:end) = [] ;

%% ################################### Plotting PC ###################################
figure;     hold on
colors = get(gca,'ColorOrder');
colors = colors([1 5 7],:) ;
Markers  = { 's', 'o' , 'd' , '' , 'd'}

for ii = 1:3
    PC = CV{ii}.CVstat(:,2) ;
    plot(Landas , PC , Markers{ii} , 'o' , 'markerfacecolor' , colors(ii,:) , 'markeredgecolor', ...
        'none' , 'markersize' , 7 ,'color',colors(ii,:),'linestyle','-', 'linewidth',2.2)
    ylabel('CV') ; 
end
% h = gcf;
% h.Children.YAxis(1).Color = 'k' ;   h.Children.YAxis(2).Color = 'k' ;
    legend('1%','10%','20%') ; pause(0.1) ;  legend boxoff
xlabel('\lambda' , 'fontsize',22 , 'fontweight','b')

%
ax = gca;
ax.XTick(1:2:end) = [] ;
